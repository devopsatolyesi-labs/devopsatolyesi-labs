# Lab Catalog

Technology labs are introduced incrementally. Every lab must start from [LAB_TEMPLATE.md](LAB_TEMPLATE.md) and include scripts for setup, validation, cleanup, and reset when implementation begins.
