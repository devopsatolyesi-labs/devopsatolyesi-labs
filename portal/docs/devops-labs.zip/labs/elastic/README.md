# Elastic Lab

Reserved for structured log ingest, Elasticsearch, and Kibana exploration.
