#!/usr/bin/env bash
set -euo pipefail
echo "==> Validating LAB-LOG-01: Vector configuration syntax..."
docker run --rm -v "$(pwd)/vector.yaml:/etc/vector/vector.yaml:ro" timberio/vector:0.40.2-alpine validate /etc/vector/vector.yaml
echo "[PASS] Vector configuration syntax validated."
