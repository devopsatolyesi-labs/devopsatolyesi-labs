#!/usr/bin/env bash
set -euo pipefail
echo "==> Validating LAB-DOC-02: Volumes & Environment..."
docker compose config --quiet
docker compose up -d
sleep 4
docker exec lab-doc-02-db pg_isready -U devops -d training >/dev/null
echo "[PASS] PostgreSQL volume and credentials verified."
docker compose down -v
