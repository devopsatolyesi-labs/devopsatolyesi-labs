#!/usr/bin/env bash
docker compose down -v 2>/dev/null || true
echo "Cleanup completed for LAB-DOC-02."
