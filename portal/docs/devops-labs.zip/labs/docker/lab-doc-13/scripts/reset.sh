#!/usr/bin/env bash
# ==============================================================================
# Script: reset.sh
# Purpose: Resets student workspace to clean starter files
# ==============================================================================
set -euo pipefail

TARGET_DIR="${HOME}/devops-workspace/labs/LAB-DOC-13"
ASSETS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "==> Cleaning existing containers..."
bash "${ASSETS_DIR}/scripts/cleanup.sh"

echo "==> Restoring starter templates to $TARGET_DIR..."
mkdir -p "$TARGET_DIR"
cp -r "${ASSETS_DIR}/starter/"* "$TARGET_DIR/" 2>/dev/null || true

echo "==> LAB-DOC-13 reset completed."
