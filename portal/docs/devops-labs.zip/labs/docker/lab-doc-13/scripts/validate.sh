#!/usr/bin/env bash
# ==============================================================================
# Script: validate.sh
# Purpose: Validates Enterprise Docker Compose Patterns (LAB-DOC-13)
# ==============================================================================
set -euo pipefail

echo "=========================================================="
echo "  VALIDATING ENTERPRISE DOCKER COMPOSE PATTERNS (LAB-DOC-13)"
echo "=========================================================="

PASS=0
FAIL=0

log_pass() { echo -e "[\033[32mPASS\033[0m] $1"; PASS=$((PASS+1)); }
log_fail() { echo -e "[\033[31mFAIL\033[0m] $1"; FAIL=$((FAIL+1)); }

TARGET_DIR="${HOME}/devops-workspace/labs/LAB-DOC-13"
cd "$TARGET_DIR"

# 1. Compose Config Syntax Check
if docker compose config >/dev/null 2>&1; then
  log_pass "Docker Compose YAML syntax and extension anchors successfully resolved."
else
  log_fail "Docker Compose config validation failed."
fi

# 2. Service Health Status Checks
GATEWAY_STATUS=$(docker inspect --format '{{.State.Status}}' enterprise-gateway 2>/dev/null || echo "missing")
if [ "$GATEWAY_STATUS" = "running" ]; then
  log_pass "Reverse Proxy Gateway (NGINX) is running."
else
  log_fail "Gateway container is $GATEWAY_STATUS."
fi

API_HEALTH=$(docker inspect --format '{{.State.Health.Status}}' enterprise-order-api 2>/dev/null || echo "missing")
if [ "$API_HEALTH" = "healthy" ]; then
  log_pass "Order API Service is healthy."
else
  log_fail "Order API health status is '$API_HEALTH' (expected 'healthy')."
fi

PG_HEALTH=$(docker inspect --format '{{.State.Health.Status}}' enterprise-postgres 2>/dev/null || echo "missing")
if [ "$PG_HEALTH" = "healthy" ]; then
  log_pass "PostgreSQL Database is healthy."
else
  log_fail "Postgres health status is '$PG_HEALTH'."
fi

REDIS_HEALTH=$(docker inspect --format '{{.State.Health.Status}}' enterprise-redis 2>/dev/null || echo "missing")
if [ "$REDIS_HEALTH" = "healthy" ]; then
  log_pass "Redis Broker is healthy."
else
  log_fail "Redis health status is '$REDIS_HEALTH'."
fi

# 3. HTTP Endpoints via Gateway
RESPONSE=$(curl -sf http://localhost:8080/healthz 2>/dev/null || echo "ERROR")
if echo "$RESPONSE" | grep -q "HEALTHY"; then
  log_pass "Gateway routed request to API: $RESPONSE"
else
  log_fail "Gateway HTTP health check failed: $RESPONSE"
fi

# 4. Production Network Isolation Check (Postgres should NOT be reachable on host in prod mode)
if ! nc -z -w 2 localhost 5432 >/dev/null 2>&1; then
  log_pass "Network Isolation: PostgreSQL port 5432 is NOT exposed to the host (Zero Trust)."
else
  # If developer override is active, notice that
  echo -e "[\033[33mINFO\033[0m] Port 5432 open on host (compose.override.yaml active in dev mode)."
fi

echo "----------------------------------------------------------"
echo "  SUMMARY: PASS=$PASS | FAIL=$FAIL"
echo "----------------------------------------------------------"

if [ "$FAIL" -eq 0 ]; then
  echo -e "  RESULT: \033[32mENTERPRISE COMPOSE PATTERNS FULLY VALIDATED\033[0m"
  exit 0
else
  echo -e "  RESULT: \033[31mVALIDATION FAILED\033[0m"
  exit 1
fi
