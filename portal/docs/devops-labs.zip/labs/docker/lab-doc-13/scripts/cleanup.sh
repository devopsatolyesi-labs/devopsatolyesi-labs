#!/usr/bin/env bash
# ==============================================================================
# Script: cleanup.sh
# Purpose: Gracefully stops containers, removes volumes and networks
# ==============================================================================
set -euo pipefail

TARGET_DIR="${HOME}/devops-workspace/labs/LAB-DOC-13"

if [ -d "$TARGET_DIR" ]; then
  echo "==> Stopping Docker Compose stack in $TARGET_DIR..."
  (cd "$TARGET_DIR" && docker compose --profile "*" down -v --remove-orphans 2>/dev/null || true)
fi

echo "==> Cleanup complete."
