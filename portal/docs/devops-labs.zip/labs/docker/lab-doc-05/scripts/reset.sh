#!/usr/bin/env bash
set -euo pipefail

echo "==> Resetting LAB-DOC-05..."
docker compose down -v --rmi all 2>/dev/null || true
echo "Reset completed. Environment is clean."
