#!/usr/bin/env bash
set -euo pipefail

echo "==> Validating LAB-DOC-05 Multi-Tier Compose Stack..."
HEALTH_STATUS=$(curl -sf http://localhost:8080/healthz | jq -r .status || echo "FAIL")

if [ "$HEALTH_STATUS" = "HEALTHY" ]; then
  echo "PASS: Multi-tier stack is healthy and communicating with Postgres and Redis."
  exit 0
else
  echo "FAIL: Health check failed with status: $HEALTH_STATUS"
  exit 1
fi
