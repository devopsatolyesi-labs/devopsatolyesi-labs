#!/usr/bin/env bash
set -euo pipefail
echo "==> Validating LAB-DOC-04: Multi-stage Hardening..."
docker build -t lab-doc-04-hardened:latest . >/dev/null
USER_ID=$(docker run --rm lab-doc-04-hardened:latest id -u)
if [ "$USER_ID" = "10001" ]; then
    echo "[PASS] Container executes as non-root user 10001."
    exit 0
else
    echo "[FAIL] Expected UID 10001, found $USER_ID"
    exit 1
fi
