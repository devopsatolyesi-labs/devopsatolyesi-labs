#!/usr/bin/env bash
set -euo pipefail
echo "==> Validating LAB-DOC-06: Trivy Security Scan..."
bash trivy-scan.sh
echo "[PASS] Trivy blocking scan passed on hardened baseline image."
