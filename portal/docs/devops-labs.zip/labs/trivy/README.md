# Trivy Lab

Reserved for image and dependency scanning exercises.
