# Docker Python Lab

This small Flask application teaches one concept: turn a tested Python service
into a non-root Docker image.

```bash
docker build --target test -t docker-python-lab-test .
docker build --target runtime -t docker-python-lab .
docker run --rm -p 8080:8080 docker-python-lab
curl http://localhost:8080/health
```

The Jenkinsfile performs the same two builds. It deliberately does not push,
deploy, scan, or use credentials; those are separate labs.
