from flask import Flask, jsonify

app = Flask(__name__)


@app.get("/")
def index():
    return jsonify(application="docker-python-lab", message="Containerized Python app is running")


@app.get("/health")
def health():
    return jsonify(status="healthy")
