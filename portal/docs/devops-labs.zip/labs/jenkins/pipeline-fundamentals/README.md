# Jenkins Pipeline Fundamentals

Small, independently runnable Pipeline-as-Code labs. Configure each Jenkins job
with this repository as its SCM source and select the listed `Jenkinsfile`.

| Lab | Jenkinsfile | Focus |
| --- | --- | --- |
| Declarative basics | `labs/01-declarative-basics/Jenkinsfile` | stages, shell steps and archived artifacts |
| Parameters | `labs/02-parameters/Jenkinsfile` | typed build parameters and validation |
| Conditional execution | `labs/03-when/Jenkinsfile` | the declarative `when` directive |
| Downstream build | `labs/04-downstream/Jenkinsfile` | one job triggering another job |

These jobs intentionally do not publish images or deploy applications. Those
are separate CI/CD labs.
