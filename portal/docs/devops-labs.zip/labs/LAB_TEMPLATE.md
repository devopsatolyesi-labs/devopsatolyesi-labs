# Lab Template

## Objective

State the practical learner outcome.

## Level

Choose one: CORE / PRACTITIONER / CHALLENGE.

## Estimated time

State a realistic timebox.

## Prerequisites

List required knowledge, tools, and starting services.

## Architecture / topology

Describe components, network relationships, and relevant ports.

## Starter state

Describe what is already present and how to verify it.

## Step-by-step

Give numbered, copyable learner actions with expected checkpoints.

## Expected output

Show the observable successful result.

## Validation

Provide an automated script or exact verification commands.

## Cleanup

Give safe, idempotent cleanup steps.

## Troubleshooting

List likely symptoms, diagnosis, and recovery.

## Production notes

Explain how production practice differs from this lab.

## Challenge

Offer an optional advanced extension.
