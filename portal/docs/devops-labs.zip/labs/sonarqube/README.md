# SonarQube Lab

Reserved for static analysis, quality gates, and CI integration.
