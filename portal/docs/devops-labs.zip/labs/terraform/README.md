# Terraform Lab

Reserved for init, plan, apply, destroy, and Docker/Kubernetes/Helm provider exercises.
