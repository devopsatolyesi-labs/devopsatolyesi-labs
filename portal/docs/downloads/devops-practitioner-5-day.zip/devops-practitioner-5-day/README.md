# DevOps Practitioner Eğitim Paketi

Labları numara sırasıyla ilerletin. Paket çözüm dosyası içermez.
