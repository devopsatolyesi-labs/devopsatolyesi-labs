# Docker ve Kubernetes Eğitim Paketi

Labları numara sırasıyla ilerletin. Paket çözüm dosyası içermez.
